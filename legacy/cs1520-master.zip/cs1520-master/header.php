<?php
/**
 * Created by PhpStorm.
 * User: cas275
 * Date: 3/11/16
 * Time: 6:36 PM
 */
echo "<header>
        <div>
            <img src='logo_SpeedRunsLive_outline.png' alt='logo' style='height: 50px'>
        </div>
        <div>
            <h2>Games by Letter</h2>
            <nav>

                    <a href='A.php'>A</a>
                    <a href='B.php'>B</a>
                    <a href='C.php'>C</a>
                    <a href='D.php'>D</a>
                    <a href='E.php'>E</a>
                    <a href='F.php'>F</a>
                    <a href='G.php'>G</a>
                    <a href='H.php'>H</a>
                    <a href='I.php'>I</a>
                    <a href='J.php'>J</a>
                    <a href='K.php'>K</a>
                    <a href='L.php'>L</a>
                    <a href='M.php'>M</a>
                    <a href='N.php'>N</a>
                    <a href='O.php'>O</a>
                    <a href='P.php'>P</a>
                    <a href='Q.php'>Q</a>
                    <a href='R.php'>R</a>
                    <a href='S.php'>S</a>
                    <a href='T.php'>T</a>
                    <a href='U.php'>U</a>
                    <a href='V.php'>V</a>
                    <a href='W.php'>W</a>
                    <a href='X.php'>X</a>
                    <a href='Y.php'>Y</a>
                    <a href='Z.php'>Z</a>

            </nav>
        </div>
    </header>";