<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="UTF-8">
    <title> Split Comparator</title>
    <link rel="stylesheet" type="text/css" href="split_styles.css">
</head>

<body>
<?php include 'header.php'; ?>
<div class="login">
    <form action = "login.php" method = "post">
        User Name: <input type = "text" name = "name"><br>
        Password:  <input type="text" name = "password"><br>
        <input type = "submit">

    </form>
    <a href='create.php'>Join Site</a>
    <a href='forgot.php'>Forgot Password</a>
</div>

</body>
</html>


